// このファイルは無効化されました
// Firebase統合により不要となったため、shared-users-database.js.disabledにリネームされました
console.log('⚠️ [DISABLED] shared-users-database.jsは無効化されています');